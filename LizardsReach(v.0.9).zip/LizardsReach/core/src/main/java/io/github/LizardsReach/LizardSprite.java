package io.github.LizardsReach;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;

public class LizardSprite extends Sprite {
    private TextureAtlas textureAtlas;
    private Animation walkAnimation;
    private Animation attackAnimation;
    private Array<TextureAtlas.AtlasRegion> walkFrames;
    private Array<TextureAtlas.AtlasRegion> attackFrames;

    private boolean walking;
    private boolean walkingLeft;
    private boolean walkingRight;
    private boolean attacking;
    private boolean jumping;

    public LizardSprite() {
        textureAtlas = new TextureAtlas(Gdx.files.internal("LizardSprite.atlas"));
        float frameDuration = 1/5f;
        walkFrames = textureAtlas.findRegions("IMG");
        walkAnimation = new Animation(frameDuration, walkFrames);
        attackFrames = textureAtlas.findRegions("attack");
        attackAnimation = new Animation(frameDuration, attackFrames);

        setBounds(0,0, walkFrames.get(0).getRegionWidth(), walkFrames.get(0).getRegionHeight());
        setRegion(walkFrames.get(0));
    }

    public void setState(boolean left, boolean right, boolean jump) {
        walkingLeft = left;
        walkingRight = right;
        jumping = jump;
        walking = (walkingLeft || walkingRight) && !jumping;
    }

    public void updateSprite(float elapsedTime) {
        if (walking) {
            TextureRegion currentFrame = (TextureRegion) walkAnimation.getKeyFrame(elapsedTime, true);

            if (walkingLeft) {
                if (currentFrame.isFlipX()) {
                    currentFrame.flip(true, false); // Unflip if currently flipped
                }
                setRegion(currentFrame);
            }
            if (walkingRight) {
                if (!currentFrame.isFlipX()) {
                    currentFrame.flip(true, false); // Flip horizontally if not already flipped
                }
                setRegion(currentFrame);
            }
        }
        if (attacking) {
            setRegion((TextureRegion) attackAnimation.getKeyFrame(elapsedTime, false));
        }
    }

}
