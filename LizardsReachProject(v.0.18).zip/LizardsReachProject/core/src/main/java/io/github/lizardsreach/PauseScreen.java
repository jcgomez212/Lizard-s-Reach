package io.github.lizardsreach;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class PauseScreen implements Screen {
    private final LizardGame game;
    private SpriteBatch batch;
    private BitmapFont font;

    public PauseScreen(LizardGame game) {
        this.game = game;
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(2);
        font.setColor(1, 1, 1, 1);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        batch.begin();
        font.draw(batch, "Resume (R)", LizardGame.VIRTUAL_WIDTH / 2f - 50, LizardGame.VIRTUAL_HEIGHT / 2f + 20);
        font.draw(batch, "Menu (M)", LizardGame.VIRTUAL_WIDTH / 2f - 50, LizardGame.VIRTUAL_HEIGHT / 2f - 20);
        batch.end();

        // KK: Stop background music when paused
        if (game.getBackgroundMusic() != null) {
            game.getBackgroundMusic().stop();
        }

        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.R)) {
            game.setScreen(game.getPreviousScreen()); // Resume previous screen
        }
        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.M)) {
            game.setScreen(new MainMenu(game)); // Return to main menu
        }
    }

    @Override public void resize(int width, int height) {}
    @Override public void show() {}
    @Override public void hide() {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void dispose() {
        batch.dispose();
        font.dispose();
    }
}
