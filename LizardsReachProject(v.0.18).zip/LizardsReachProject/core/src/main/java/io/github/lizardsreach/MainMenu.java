package io.github.lizardsreach;

import com.badlogic.gdx.audio.Music; // CC: Added import for Music
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class MainMenu implements Screen {
    private final LizardGame game;
    private SpriteBatch batch;
    private Texture cityBackground;
    private BitmapFont font;

    private Music backgroundMusic; // CC: Added background music

    public MainMenu(LizardGame game) {
        this.game = game;
        batch = new SpriteBatch();
        cityBackground = new Texture("menuBackground.png");
        font = new BitmapFont();
        font.getData().setScale(3);
        font.setColor(1, 1, 1, 1);

        try {
            // Initialize and play Party.mp3
            backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("Party.mp3"));
            backgroundMusic.setLooping(true);
            backgroundMusic.setVolume(0.25f); // 25% volume
            backgroundMusic.play();
            System.out.println("Party.mp3 initialized and playing in MainMenu.");
        } catch (Exception e) {
            System.err.println("Error initializing Party.mp3 in MainMenu: " + e.getMessage());
        }
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);

        batch.begin();
        batch.draw(cityBackground, 0, 0, LizardGame.VIRTUAL_WIDTH, LizardGame.VIRTUAL_HEIGHT);
        font.draw(batch, "Start Game (S)", LizardGame.VIRTUAL_WIDTH / 2f - 100, LizardGame.VIRTUAL_HEIGHT / 2f - 50);
        font.draw(batch, "How To Play (H)", LizardGame.VIRTUAL_WIDTH / 2f - 100, LizardGame.VIRTUAL_HEIGHT / 2f - 100);
        batch.end();

        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.S)) {
            backgroundMusic.stop(); // CC: Stop music when leaving the screen
            game.setScreen(new GameScreen(game)); // Start GameScreen
        }

        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.H)) {
            backgroundMusic.stop(); // CC: Stop music when leaving the screen
            game.setScreen(new HelpScreen(game)); // Open HelpScreen
        }
    }

    @Override
    public void resize(int width, int height) {}

    @Override
    public void show() {}

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {
        batch.dispose();
        cityBackground.dispose();
        font.dispose();

        if (backgroundMusic != null) {
            backgroundMusic.dispose();
            System.out.println("Party.mp3 disposed in MainMenu.");
        }
    }
}
