package io.github.lizardsreach;

import com.badlogic.gdx.Game;

public class LizardGame extends Game {
    public static final int VIRTUAL_WIDTH = 960;
    public static final int VIRTUAL_HEIGHT = 720;

    @Override
    public void create() {
        setScreen(new MainMenu(this));
    }
}
