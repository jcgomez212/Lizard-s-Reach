package io.github.lizardsreach;

import com.badlogic.gdx.audio.Sound; // CC: Added imports for SFX
import com.badlogic.gdx.audio.Music; // CC: Added imports for music
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.Iterator;

public class GameScreen implements Screen {
    private final LizardGame game; // BB: Reference to main game class
    private SpriteBatch batch;
    private Texture cityBackground;
    private TextureAtlas lizardAtlas;
    private Animation<TextureRegion> lizardAnimation;
    private TextureRegion currentFrame;
    private TextureRegion idleFrame;
    private TextureAtlas flyAtlas;
    private Texture heartTexture;
    private Animation<TextureRegion> flyAnimation;
    private float stateTime;
    private float lizardX, lizardY;
    private float jumpVelocity;
    private boolean isJumping;
    private boolean isMoving;
    private boolean isAttacking;
    private boolean isFlipped;
    private boolean isOnCooldown;
    private float cooldownTimer;
    private float attackStartX, attackStartY, attackEndX, attackEndY;
    private Array<Fly> flies;
    private int score;
    private BitmapFont font;

    private static final int VIRTUAL_WIDTH = 960;
    private static final int VIRTUAL_HEIGHT = 720;
    private OrthographicCamera camera;
    private Viewport viewport;

    // CC: Added SFX and music variables
    private Sound achievementSound;
    private Sound attackSound;
    private Sound jumpSound;
    private Sound walkSound;
    private Music backgroundMusic;
    private int lastAchievementScore; // CC: Tracks the last score milestone for achievement sound

    // DD: Added flags and IDs to manage sound playback
    private boolean isJumpSoundPlaying; // Tracks if the jump sound is playing
    private boolean isWalkSoundPlaying; // Tracks if the walk sound is playing
    private boolean isAttackSoundPlaying; // Tracks if the attack sound is playing
    private long walkSoundId; // ID for the looping walk sound


    public GameScreen(LizardGame game) { // BB: Constructor updated to accept game reference
        this.game = game;
        batch = new SpriteBatch();

        camera = new OrthographicCamera();
        viewport = new FitViewport(VIRTUAL_WIDTH, VIRTUAL_HEIGHT, camera);

        cityBackground = new Texture("cityBackground.png");

        lizardAtlas = new TextureAtlas(Gdx.files.internal("LizardSprite.txt"));
        Array<TextureRegion> walkingFrames = new Array<>();
        for (int i = 0; i < lizardAtlas.getRegions().size - 1; i++) {
            walkingFrames.add(lizardAtlas.getRegions().get(i));
        }
        lizardAnimation = new Animation<>(0.1f, walkingFrames);
        idleFrame = lizardAtlas.getRegions().first();

        lizardX = VIRTUAL_WIDTH / 2f - 75;
        lizardY = 100;
        stateTime = 0f;
        jumpVelocity = 0f;
        isJumping = false;
        isMoving = false;
        isAttacking = false;
        isOnCooldown = false;
        cooldownTimer = 0f;
        score = 0;

        font = new BitmapFont();
        font.getData().setScale(2);
        font.setColor(1, 1, 1, 1);

        heartTexture = new Texture("heart.png");

        flyAtlas = new TextureAtlas(Gdx.files.internal("FlySprite.txt"));
        flyAnimation = new Animation<>(0.1f, flyAtlas.getRegions());
        flies = new Array<>();

        achievementSound = Gdx.audio.newSound(Gdx.files.internal("sounds/achievement.mp3"));
        attackSound = Gdx.audio.newSound(Gdx.files.internal("sounds/attack.mp3"));
        jumpSound = Gdx.audio.newSound(Gdx.files.internal("sounds/jumpy.mp3"));
        walkSound = Gdx.audio.newSound(Gdx.files.internal("sounds/walk.mp3"));
        walkSound.loop();
        walkSound.pause();

        // Initialize and play Party.mp3
        backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("sounds/Party.mp3"));
        backgroundMusic.setLooping(true);
        backgroundMusic.setVolume(5.0f); // 25% volume
        backgroundMusic.play();

        lastAchievementScore = 0; // CC: Initialize last achievement score
    }

    @Override
    public void render(float delta) {
        camera.update();
        batch.setProjectionMatrix(camera.combined);

        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);

        stateTime += Gdx.graphics.getDeltaTime();

        handleInput();

        // DD: Ensure attack state updates correctly
        updateAttack();

        // CC: Play achievement sound every 500 points
        if (score >= lastAchievementScore + 500) {
            achievementSound.play(1.0f); // 10% volume
            lastAchievementScore += 500;
        }

        if (isOnCooldown) {
            cooldownTimer -= Gdx.graphics.getDeltaTime();
            if (cooldownTimer <= 0) {
                isOnCooldown = false;
                isAttacking = false;
            }
        }

        if (isAttacking) {
            attackStartX = lizardX + currentFrame.getRegionWidth() * 1.5f;
            attackStartY = lizardY + currentFrame.getRegionHeight() * 3;

            float dx = attackEndX - attackStartX;
            float dy = attackEndY - attackStartY;
            float distance = (float) Math.sqrt(dx * dx + dy * dy);

            if (distance > 250) {
                float scale = 250 / distance;
                attackEndX = attackStartX + dx * scale;
                attackEndY = attackStartY + dy * scale;
            }
        }

        if (isAttacking) {
            currentFrame = lizardAtlas.getRegions().get(lizardAtlas.getRegions().size - 1);
        } else if (isMoving || isJumping) {
            currentFrame = lizardAnimation.getKeyFrame(stateTime, true);
        } else {
            currentFrame = idleFrame;
        }

        if (isMoving)
            walkSound.resume();
        else
            walkSound.pause();

        updateFlies();

        batch.begin();
        batch.draw(cityBackground, 0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
        drawHearts();
        if (isAttacking) drawAttackRectangle();
        drawLizardMan();
        drawFlies();
        font.draw(batch, "Score: " + score, 10, VIRTUAL_HEIGHT - 10);
        batch.end();

        updateJump();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0);
    }

    @Override
    public void show() {
        // BB: This method is required by the Screen interface but does not need functionality here
    }

    @Override
    public void hide() {
        // BB: This method is required by the Screen interface but does not need functionality here
    }

    @Override
    public void pause() {
        // BB: This method is required by the Screen interface but does not need functionality here
    }

    @Override
    public void resume() {
        // BB: This method is required by the Screen interface but does not need functionality here
    }

    private void drawLizardMan() {
        if (isFlipped && !currentFrame.isFlipX()) {
            currentFrame.flip(true, false);
        } else if (!isFlipped && currentFrame.isFlipX()) {
            currentFrame.flip(true, false);
        }
        batch.draw(currentFrame, lizardX, lizardY, currentFrame.getRegionWidth() * 3, currentFrame.getRegionHeight() * 3);
    }

    private void drawAttackRectangle() {
        batch.end();
        ShapeRenderer shapeRenderer = new ShapeRenderer();
        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(1, 0, 0, 1);
        shapeRenderer.rectLine(attackStartX, attackStartY, attackEndX, attackEndY, 5);
        shapeRenderer.end();
        batch.begin();
    }

    private void drawFlies() {
        Iterator<Fly> iterator = flies.iterator();
        while (iterator.hasNext()) {
            Fly fly = iterator.next();
            TextureRegion currentFrame = flyAnimation.getKeyFrame(stateTime, true);

            if (fly.flipped && !currentFrame.isFlipX()) {
                currentFrame.flip(true, false);
            } else if (!fly.flipped && currentFrame.isFlipX()) {
                currentFrame.flip(true, false);
            }

            // Check if the fly is hit
            if (isAttacking && fly.boundingBox.overlaps(new Rectangle(attackStartX, attackStartY, attackEndX - attackStartX, attackEndY - attackStartY))) {
                score += fly.isGolden ? 500 : 100; // Golden flies are worth 500 points
                iterator.remove();
                continue;
            }

            // Apply shimmering effect for golden flies
            if (fly.isGolden) {
                float shimmer = (MathUtils.sin(stateTime * 5) + 1) / 2; // Oscillates between 0 and 1
                batch.setColor(1, 0.8f + shimmer * 0.2f, 0, 1); // Bright yellow with shimmer
            } else {
                batch.setColor(1, 1, 1, 1); // Default color
            }

            batch.draw(currentFrame, fly.x - fly.size / 2, fly.y, fly.size, fly.size);
            fly.update(Gdx.graphics.getDeltaTime());

            if (fly.x < -fly.size || fly.x > VIRTUAL_WIDTH + fly.size) {
                iterator.remove();
            }
        }

        batch.setColor(1, 1, 1, 1); // Reset color after rendering
    }

    private void handleInput() {
        if (isOnCooldown) return;

        // Allow simultaneous movement and attacking
        isMoving = false;

        // Handle left movement
        if (Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.A)) {
            lizardX -= 200 * Gdx.graphics.getDeltaTime();
            isMoving = true;
            isFlipped = true;
        }

        // Handle right movement
        if (Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.D)) {
            lizardX += 200 * Gdx.graphics.getDeltaTime();
            isMoving = true;
            isFlipped = false;
        }

        // Handle jump
        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.W) && !isJumping) {
            isJumping = true;
            jumpVelocity = 800f;
            jumpSound.play();
        }

        // Handle attack
        if (Gdx.input.isButtonJustPressed(com.badlogic.gdx.Input.Buttons.LEFT)) {
            isAttacking = true;
            isOnCooldown = true;
            cooldownTimer = 0.8f;

            attackSound.play(0.15f); // Play attack sound at 15% volume

            attackStartX = lizardX + currentFrame.getRegionWidth() * 1.5f;
            attackStartY = lizardY + currentFrame.getRegionHeight() * 3;

            float clickX = camera.unproject(new com.badlogic.gdx.math.Vector3(Gdx.input.getX(), Gdx.input.getY(), 0)).x;
            float clickY = camera.unproject(new com.badlogic.gdx.math.Vector3(Gdx.input.getX(), Gdx.input.getY(), 0)).y;

            float dx = clickX - attackStartX;
            float dy = clickY - attackStartY;
            float distance = (float) Math.sqrt(dx * dx + dy * dy);

            if (distance > 250) {
                float scale = 250 / distance;
                attackEndX = attackStartX + dx * scale;
                attackEndY = attackStartY + dy * scale;
            } else {
                attackEndX = clickX;
                attackEndY = clickY;
            }
        }
    }

    private void updateJump() {
        if (isJumping) {
            lizardY += jumpVelocity * Gdx.graphics.getDeltaTime();
            jumpVelocity -= 1200 * Gdx.graphics.getDeltaTime();

            if (lizardY <= 100) {
                lizardY = 100;
                isJumping = false;

                // DD: Reset jump sound flag when jump ends
                isJumpSoundPlaying = false;
            }
        }
    }

    private void updateAttack() {
        if (!Gdx.input.isButtonJustPressed(com.badlogic.gdx.Input.Buttons.LEFT)) {
            // DD: Reset attack sound flag after the attack ends
            isAttackSoundPlaying = false;
        }
    }

    private void updateFlies() {
        if (MathUtils.random(0, 100) < 2) {
            float flySize = MathUtils.random(30, 70);
            float flySpeed = MathUtils.random(150, 300);
            float flyY = MathUtils.random(200, VIRTUAL_HEIGHT - flySize - 50);
            boolean isGolden = flyY > VIRTUAL_HEIGHT * 0.8f; // Top 10% of the screen

            if (MathUtils.randomBoolean()) {
                flies.add(new Fly(0, flyY, flySize, flySpeed, false, isGolden));
            } else {
                flies.add(new Fly(VIRTUAL_WIDTH, flyY, flySize, -flySpeed, true, isGolden));
            }
        }
    }

    @Override
    public void dispose() {
        try {
            batch.dispose();
            cityBackground.dispose();
            lizardAtlas.dispose();
            flyAtlas.dispose();
            font.dispose();
            heartTexture.dispose();

            // DD: Dispose audio resources properly
            achievementSound.dispose();
            attackSound.dispose();
            jumpSound.dispose();
            walkSound.dispose();
            backgroundMusic.dispose();
        } catch (Exception e) {
            System.err.println("Error disposing resources: " + e.getMessage());
        }
        if (backgroundMusic != null) {
            backgroundMusic.dispose();
            System.out.println("Party.mp3 disposed in GameScreen.");
        }
    }

    private static class Fly {
        float x, y, size, speed;
        boolean flipped;
        boolean isGolden; // New property for golden flies
        Rectangle boundingBox;

        Fly(float x, float y, float size, float speed, boolean flipped, boolean isGolden) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.speed = speed;
            this.flipped = flipped;
            this.isGolden = isGolden;
            this.boundingBox = new Rectangle(x - size / 2, y, size, size);
        }

        void update(float deltaTime) {
            x += speed * deltaTime;
            boundingBox.setPosition(x - size / 2, y);
        }
    }

    private void drawHearts() {
        int heartSize = 50;
        int spacing = 10;
        int startX = 10;
        int startY = VIRTUAL_HEIGHT - heartSize - 50;

        for (int i = 0; i < 3; i++) {
            batch.draw(heartTexture, startX + i * (heartSize + spacing), startY, heartSize, heartSize);
        }
    }

    private void drawFlyRectangles() {
        ShapeRenderer shapeRenderer = new ShapeRenderer();
        shapeRenderer.setProjectionMatrix(camera.combined);

        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(0, 1, 0, 1);
        for (Fly fly : flies) {
            shapeRenderer.rect(fly.boundingBox.x, fly.boundingBox.y, fly.boundingBox.width, fly.boundingBox.height);
        }
        shapeRenderer.end();
    }
}
