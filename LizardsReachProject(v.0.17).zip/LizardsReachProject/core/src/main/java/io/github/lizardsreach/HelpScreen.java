package io.github.lizardsreach;

import com.badlogic.gdx.audio.Music; // CC: Added import for Music
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class HelpScreen implements Screen {
    private final LizardGame game;
    private SpriteBatch batch;
    private BitmapFont font;

    private Music backgroundMusic; // CC: Added background music

    public HelpScreen(LizardGame game) {
        this.game = game;
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(2);
        font.setColor(1, 1, 1, 1);

        try {
            // Initialize and play Party.mp3
            backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("Party.mp3"));
            backgroundMusic.setLooping(true);
            backgroundMusic.setVolume(0.25f); // 25% volume
            backgroundMusic.play();
            System.out.println("Party.mp3 initialized and playing in HelpScreen.");
        } catch (Exception e) {
            System.err.println("Error initializing Party.mp3 in HelpScreen: " + e.getMessage());
        }
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);

        batch.begin();
        font.draw(batch, "How to Play:\n" +
                "\nUse the W, A, and D keys to PLAY\n" +
                "Press A or D to move LEFT or RIGHT\n" +
                "Press W to JUMP\n" +
                "Use the cursor to click flies and collect FLY POINTS ;) ",
            LizardGame.VIRTUAL_WIDTH / 4f, LizardGame.VIRTUAL_HEIGHT / 2f);
        font.draw(batch, "Go Back (B)", 10, 30);
        batch.end();

        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.B)) {
            backgroundMusic.stop(); // CC: Stop music when leaving the screen
            game.setScreen(new MainMenu(game)); // Return to MainMenu
        }
    }

    @Override
    public void resize(int width, int height) {}

    @Override
    public void show() {}

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {
        batch.dispose();
        font.dispose();

        if (backgroundMusic != null) {
            backgroundMusic.dispose();
            System.out.println("Party.mp3 disposed in HelpScreen.");
        }
    }
}
