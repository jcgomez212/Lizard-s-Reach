package io.github.lizardsreach;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;

public class LizardGame extends Game {
    private Screen previousScreen; // JJ: Field to store the previous screen
    public static final int VIRTUAL_WIDTH = 960;
    public static final int VIRTUAL_HEIGHT = 720;
    private Music backgroundMusic; // JJ: Background music for the game

    public Music getBackgroundMusic() {
        return backgroundMusic;
    }

    @Override
    public void create() {
        setScreen(new MainMenu(this));
    }
    @Override
    public void setScreen(Screen screen) {
        // JJ: Save the current screen as the previous screen before switching
        if (this.screen != null) {
            previousScreen = this.screen;
        }
        super.setScreen(screen); // Call the parent method to change the screen
    }

    // JJ: Method to return the previously active screen
    public Screen getPreviousScreen() {
        return previousScreen;
    }
}
