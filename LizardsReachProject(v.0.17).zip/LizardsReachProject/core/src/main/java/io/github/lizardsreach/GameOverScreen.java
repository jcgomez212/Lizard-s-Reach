package io.github.lizardsreach;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class GameOverScreen implements Screen {
    private final LizardGame game;
    private SpriteBatch batch;
    private Texture gameOverBackground;
    private BitmapFont font;

    public GameOverScreen(LizardGame game) {
        this.game = game;
        batch = new SpriteBatch();
        gameOverBackground = new Texture("gameOver.png");
        font = new BitmapFont();
        font.getData().setScale(2);
        font.setColor(1, 1, 1, 1); // White color for text
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        batch.begin();
        batch.draw(gameOverBackground, 0, 0, LizardGame.VIRTUAL_WIDTH, LizardGame.VIRTUAL_HEIGHT);
        font.draw(batch, "Press R to RESTART", LizardGame.VIRTUAL_WIDTH / 2f - 100, LizardGame.VIRTUAL_HEIGHT / 2f - 95);
        font.draw(batch, "Press M for MENU", LizardGame.VIRTUAL_WIDTH / 2f - 100, LizardGame.VIRTUAL_HEIGHT / 2f - 145);
        batch.end();

        // Restart the game
        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.R)) {
            game.setScreen(new GameScreen(game)); // Start a new game
        }

        // Return to the main menu
        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.M)) {
            game.setScreen(new MainMenu(game)); // Navigate to main menu
        }
    }

    @Override
    public void resize(int width, int height) {}

    @Override
    public void show() {}

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {
        batch.dispose();
        gameOverBackground.dispose();
        font.dispose();

        // JJ: Stop Party.mp3 to prevent audio overlaps
        Music backgroundMusic = game.getBackgroundMusic(); // JJ: Access via LizardGame
        if (backgroundMusic != null) {
            backgroundMusic.stop();
            backgroundMusic.dispose();
        }
    }
}
