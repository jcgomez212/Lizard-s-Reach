package com.github.lizardsreach;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class LizardCharacter {
    private Animation<TextureRegion> walkAnimation;
    private Animation<TextureRegion> climbAnimation;
    private float stateTime;
    private Texture walkTexture;
    private Texture climbTexture;
    private boolean isMoving;

    public LizardCharacter() {
        walkTexture = new Texture("Walking.png");
        climbTexture = new Texture("Climbing.png");

        walkAnimation = createAnimation(walkTexture, 8);
        climbAnimation = createAnimation(climbTexture, 3);
        stateTime = 0f;
        isMoving = false;
    }

    private Animation<TextureRegion> createAnimation(Texture texture, int frameCount) {
        int frameWidth = texture.getWidth() / frameCount;
        int frameHeight = texture.getHeight();
        TextureRegion[] frames = new TextureRegion[frameCount];

        for (int i = 0; i < frameCount; i++) {
            frames[i] = new TextureRegion(texture, i * frameWidth, 0, frameWidth, frameHeight);
        }
        return new Animation<>(0.08f, frames);  // 10-12 fps animation speed
    }

    public void update(float delta) {
        if (isMoving) {
            stateTime += delta;
        } else {
            stateTime = 0;
        }
    }

    public void render(SpriteBatch batch, float x, float y, boolean climbing) {
        TextureRegion currentFrame = climbing ? climbAnimation.getKeyFrame(stateTime, true) : walkAnimation.getKeyFrame(stateTime, true);
        batch.draw(currentFrame, x, y, currentFrame.getRegionWidth() * 2, currentFrame.getRegionHeight() * 2);
    }

    public void setMoving(boolean moving) {
        isMoving = moving;
    }

    public int getWidth() {
        return walkTexture.getWidth() / 8 * 2; // Adjusted for scaling
    }

    public int getHeight() {
        return walkTexture.getHeight() * 2; // Adjusted for scaling
    }

    public void dispose() {
        walkTexture.dispose();
        climbTexture.dispose();
    }
}
