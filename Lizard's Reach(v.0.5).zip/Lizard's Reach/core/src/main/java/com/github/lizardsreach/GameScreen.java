package com.github.lizardsreach;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class GameScreen implements Screen {
    private final MainGame game;
    private OrthographicCamera camera;
    private Viewport viewport;
    private BitmapFont font;

    private Texture sky, buildingsBack, buildingsFront, bush, fence;
    private LizardCharacter lizard;
    private float playerX, playerY, velocityY;
    private final float gravity = -0.5f;
    private final float jumpStrength = 10f;
    private boolean isJumping, isClimbing;
    private boolean isPaused = false;

    private float scrollX; // For scrolling background

    public GameScreen(MainGame game) {
        this.game = game;

        camera = new OrthographicCamera();
        viewport = new FitViewport(800, 480, camera);  // Set a default aspect ratio of 800x480
        camera.position.set(viewport.getWorldWidth() / 2, viewport.getWorldHeight() / 2, 0);

        font = new BitmapFont();
        font.getData().setScale(1.5f);
        font.setColor(Color.BLACK);

        // Load parallax background textures
        sky = new Texture("eveSky.png");
        buildingsBack = new Texture("eveBuildingsBack.png");
        buildingsFront = new Texture("eveBuildingsFront.png");
        bush = new Texture("eveBush.png");
        fence = new Texture("eveFence.png");

        // Initialize player character with animations
        lizard = new LizardCharacter();
        playerX = 100;
        playerY = 100;
        velocityY = 0;
        isJumping = false;
        isClimbing = false;
        scrollX = 0;
    }

    @Override
    public void show() {
        Gdx.app.log("GameScreen", "show called");
    }

    @Override
    public void render(float delta) {
        if (Gdx.input.isKeyJustPressed(Input.Keys.P)) {
            isPaused = !isPaused;
        }

        if (isPaused) {
            renderPauseScreen();
        } else {
            handleInput();
            updateGame(delta);
            renderGame();
        }
    }

    private void handleInput() {
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            playerX = Math.max(playerX - 2, 0);  // Ensure the player doesn’t go off-screen on the left
            lizard.setMoving(true);
            isClimbing = false;
        } else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            playerX = Math.min(playerX + 2, viewport.getWorldWidth() - lizard.getWidth());  // Keep within screen boundaries
            lizard.setMoving(true);
            isClimbing = false;
        } else {
            lizard.setMoving(false);
        }

        if (Gdx.input.isKeyPressed(Input.Keys.SPACE) && !isJumping) {
            velocityY = jumpStrength;
            isJumping = true;
        }

        if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
            isClimbing = true;
            isJumping = false;
            playerY = Math.min(playerY + 2, viewport.getWorldHeight() - lizard.getHeight());  // Climb without going off-screen
        } else if (Gdx.input.isKeyPressed(Input.Keys.DOWN) && isClimbing) {
            playerY = Math.max(playerY - 2, 0);
        }
    }

    private void updateGame(float delta) {
        if (!isClimbing) {
            if (playerY > 0 || isJumping) {
                velocityY += gravity;
                playerY += velocityY;
            } else {
                playerY = 0;
                isJumping = false;
                velocityY = 0;
            }
        }

        scrollX += 100 * delta;
        lizard.update(delta);
    }

    private void renderGame() {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();

        // Draw parallax background layers scaled to fit viewport size
        float backgroundWidth = viewport.getWorldWidth();
        float backgroundHeight = viewport.getWorldHeight();

        // Parallax effect with different speeds for each layer
        game.batch.draw(sky, -(scrollX * 0.05f) % backgroundWidth, 0, backgroundWidth, backgroundHeight);
        game.batch.draw(buildingsBack, -(scrollX * 0.1f) % backgroundWidth, 0, backgroundWidth, backgroundHeight);
        game.batch.draw(buildingsFront, -(scrollX * 0.2f) % backgroundWidth, 0, backgroundWidth, backgroundHeight);
        game.batch.draw(bush, -(scrollX * 0.3f) % backgroundWidth, 0, backgroundWidth, backgroundHeight);
        game.batch.draw(fence, -(scrollX * 0.4f) % backgroundWidth, 0, backgroundWidth, backgroundHeight);

        // Render the lizard character
        lizard.render(game.batch, playerX, playerY, isClimbing);

        // Display pause instructions in the top left corner
        font.draw(game.batch, "Press (P) to PAUSE", 10, viewport.getWorldHeight() - 10);

        game.batch.end();
    }

    private void renderPauseScreen() {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        font.setColor(Color.WHITE);
        font.draw(game.batch, "Press (P) to RESUME", viewport.getWorldWidth() / 2 - 80, viewport.getWorldHeight() / 2);
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
        // Ensure viewport scales proportionally without stretching
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {
        Gdx.app.log("GameScreen", "pause called");
    }

    @Override
    public void resume() {
        Gdx.app.log("GameScreen", "resume called");
    }

    @Override
    public void hide() {
        Gdx.app.log("GameScreen", "hide called");
    }

    @Override
    public void dispose() {
        sky.dispose();
        buildingsBack.dispose();
        buildingsFront.dispose();
        bush.dispose();
        fence.dispose();
        font.dispose();
    }
}
