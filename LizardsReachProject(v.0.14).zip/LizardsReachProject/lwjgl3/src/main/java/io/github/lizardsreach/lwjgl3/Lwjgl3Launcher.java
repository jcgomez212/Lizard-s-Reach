package io.github.lizardsreach.lwjgl3;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import io.github.lizardsreach.LizardGame;

public class Lwjgl3Launcher {
    public static void main(String[] args) {
        new Lwjgl3Application(new LizardGame(), getDefaultConfiguration()); // Pass LizardGame instead of GameScreen
    }

    private static Lwjgl3ApplicationConfiguration getDefaultConfiguration() {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setTitle("Lizard's Reach");
        config.setWindowedMode(960, 720); // Match the VIRTUAL_WIDTH and VIRTUAL_HEIGHT
        config.setResizable(false);
        config.useVsync(true);
        return config;
    }
}
