package io.github.lizardsreach;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class GameScreen implements Screen {
    private final MainGame game;
    private OrthographicCamera camera;
    private Viewport viewport;

    private Texture sky, buildingsBack, buildingsFront, bush, fence;
    private LizardCharacter lizard;
    private float playerX, playerY, velocityY;
    private final float gravity = -0.5f;
    private final float jumpStrength = 10f;
    private boolean isJumping, isClimbing;
    private float scrollX; // For scrolling background

    public GameScreen(MainGame game) {
        this.game = game;

        camera = new OrthographicCamera();
        viewport = new FitViewport(800, 480, camera);
        camera.position.set(viewport.getWorldWidth() / 2, viewport.getWorldHeight() / 2, 0);

        // Load parallax background textures
        sky = new Texture("eveSky.png");
        buildingsBack = new Texture("eveBuildingsBack.png");
        buildingsFront = new Texture("eveBuildingsFront.png");
        bush = new Texture("eveBush.png");
        fence = new Texture("eveFence.png");

        // Initialize player character with animations
        lizard = new LizardCharacter();
        playerX = 100;
        playerY = 100;
        velocityY = 0;
        isJumping = false;
        isClimbing = false;
        scrollX = 0;
    }

    @Override
    public void show() {
        // This method can be used to initialize resources or reset game state
        Gdx.app.log("GameScreen", "show called");
    }

    @Override
    public void render(float delta) {
        handleInput();

        // Apply gravity if the player is not climbing
        if (!isClimbing) {
            if (playerY > 0 || isJumping) {
                velocityY += gravity;
                playerY += velocityY;
            } else {
                playerY = 0;
                isJumping = false;
                velocityY = 0;
            }
        }

        // Update background scroll position for parallax effect
        scrollX += 100 * delta; // Scroll speed for background layers

        // Clear the screen
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();

        // Draw parallax background layers
        game.batch.draw(sky, 0 - (scrollX * 0.05f), 0);
        game.batch.draw(buildingsBack, 0 - (scrollX * 0.1f), 0);
        game.batch.draw(buildingsFront, 0 - (scrollX * 0.2f), 0);
        game.batch.draw(bush, 0 - (scrollX * 0.3f), 0);
        game.batch.draw(fence, 0 - (scrollX * 0.4f), 0);

        // Render the lizard character with appropriate animation
        lizard.update(delta);
        lizard.render(game.batch, playerX, playerY, isClimbing);

        game.batch.end();
    }

    private void handleInput() {
        // Left and right movement
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            playerX -= 5;
            isClimbing = false;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            playerX += 5;
            isClimbing = false;
        }

        // Jumping
        if (Gdx.input.isKeyPressed(Input.Keys.SPACE) && !isJumping) {
            velocityY = jumpStrength;
            isJumping = true;
        }

        // Climbing (placeholder for detecting wall collisions)
        if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
            isClimbing = true;
            isJumping = false;
            playerY += 2; // Move upwards while climbing
        }
        if (Gdx.input.isKeyPressed(Input.Keys.DOWN) && isClimbing) {
            playerY -= 2; // Move downwards while climbing
        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    @Override
    public void pause() {
        // Code to pause the game can be added here
        Gdx.app.log("GameScreen", "pause called");
    }

    @Override
    public void resume() {
        // Code to resume the game from a paused state can be added here
        Gdx.app.log("GameScreen", "resume called");
    }

    @Override
    public void hide() {
        // Called when this screen is no longer the active screen
        Gdx.app.log("GameScreen", "hide called");
    }

    @Override
    public void dispose() {
        // Clean up resources when the screen is destroyed
        sky.dispose();
        buildingsBack.dispose();
        buildingsFront.dispose();
        bush.dispose();
        fence.dispose();
    }
}
