package io.github.lizardsreach;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;

public class LizardCharacter {
    private Animation<TextureRegion> walkAnimation;
    private Animation<TextureRegion> climbAnimation;
    private float stateTime;

    public LizardCharacter() {
        TextureAtlas walkAtlas = new TextureAtlas("Walking.png");
        walkAnimation = new Animation<>(0.1f, walkAtlas.getRegions(), Animation.PlayMode.LOOP);

        TextureAtlas climbAtlas = new TextureAtlas("Climbing.png");
        climbAnimation = new Animation<>(0.1f, climbAtlas.getRegions(), Animation.PlayMode.LOOP);

        stateTime = 0f;
    }

    public void update(float delta) {
        stateTime += delta;
    }

    public void render(SpriteBatch batch, float x, float y, boolean climbing) {
        TextureRegion frame = climbing ? climbAnimation.getKeyFrame(stateTime) : walkAnimation.getKeyFrame(stateTime);
        batch.draw(frame, x, y);
    }
}
