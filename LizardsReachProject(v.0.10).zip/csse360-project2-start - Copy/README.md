This project contains starter code for Project 2 - Animated Sprites, Tiled Maps, Box2D.

Choose and modify only one of the two possible options for the project:

1 - TiledMapLevelRunner

2 - PhysicsPlatformJumper
