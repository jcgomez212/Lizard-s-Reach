//Brandon Garsson s1293728
package io.github.LizardsReach;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;

public class PhysicsPlatformJumper implements Screen, InputProcessor {
    final Project2Game game;

    // Our bread crumb back to the main menu:
    MainMenuScreen mainmenu;

    LizardSprite sprite;
    float elapsedTime;
    Sound jumpSound;
    Sound goalReachedSound;
    boolean goalReached;

    final float JUMPFORCE = 6f;
    final float WALKVELOCITY = 1.5f;

    Texture img;
    World world;
    Body body;
    Body bodyEdgeScreen;


    float platformWidthMeters = 1f;
    float platformHeightMeters = .5f;
    private Body platform1Body;
    private Body platform2Body;
    private Pixmap platformPixmap;
    private Texture platform1Texture;
    private Texture platform2Texture;
    private Sprite platform1Sprite;
    private Sprite platform2Sprite;

    Box2DDebugRenderer debugRenderer;
    Matrix4 debugMatrix;
    OrthographicCamera camera;

    boolean drawSprite = true;


    boolean right, left, jump;

    final float PIXELS_TO_METERS = 100f;

    public PhysicsPlatformJumper(final Project2Game gam, MainMenuScreen pmainmenu) {
        this.game = gam;
        this.mainmenu = pmainmenu;

        // Put Gdx.graphics origin in lower left with setToOrtho,
        // else the origin will be in the middle.
        camera = new OrthographicCamera();
        camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        //Project 2
        sprite = new LizardSprite();
        jumpSound = Gdx.audio.newSound(Gdx.files.internal("sounds/jump.wav"));

        goalReachedSound = Gdx.audio.newSound(Gdx.files.internal("sounds/goal.wav"));
        goalReachedSound.loop();
        goalReachedSound.pause();


        sprite.setPosition(Gdx.graphics.getWidth() / 2 - sprite.getWidth() / 2,
            Gdx.graphics.getHeight() / 2);


        world = new World(new Vector2(0, -10f), true);

        // Define box2d body for the sprite
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        // The body's position in meters is set using the middle of the body,
        // while the sprite's position is set using the lower left corner of the sprite.
        bodyDef.position.set((sprite.getX() + sprite.getWidth() / 2) / PIXELS_TO_METERS,
            (sprite.getY() + sprite.getHeight() / 2) / PIXELS_TO_METERS);

        body = world.createBody(bodyDef);

        body.setFixedRotation(true);

        PolygonShape shape = new PolygonShape();
        // The setAsBox() method takes half-width and half-height as arguments
        shape.setAsBox(sprite.getWidth() / 2 / PIXELS_TO_METERS,
            sprite.getHeight() / 2 / PIXELS_TO_METERS);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 0.08f;
        fixtureDef.friction = 0.5f;
        fixtureDef.restitution = 0.1f;

        body.createFixture(fixtureDef);
        shape.dispose();

        // Define box2d body for the floor
        BodyDef bodyDef2 = new BodyDef();
        bodyDef2.type = BodyDef.BodyType.StaticBody;
        float w = Gdx.graphics.getWidth() / PIXELS_TO_METERS;  // width in meters
        float h = Gdx.graphics.getHeight() / PIXELS_TO_METERS; // height in meters
        bodyDef2.position.set(0, 0);
        FixtureDef fixtureDef2 = new FixtureDef();

        EdgeShape edgeShape = new EdgeShape();
        edgeShape.set(0, 0.2f, w, 0.2f); // bottom edge (.2m height)
        fixtureDef2.shape = edgeShape;

        bodyEdgeScreen = world.createBody(bodyDef2);
        bodyEdgeScreen.createFixture(fixtureDef2);
        edgeShape.dispose();

        //Add platforms
        addPlatforms();


        addContacts();

        Gdx.input.setInputProcessor(this);

        debugRenderer = new Box2DDebugRenderer();
    }



    private void addPlatforms() {

        PolygonShape shape = new PolygonShape();

        shape.setAsBox(platformWidthMeters/2, platformHeightMeters/2);
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;


        BodyDef platform1BodyDef = new BodyDef();
        platform1BodyDef.type = BodyDef.BodyType.StaticBody;
        platform1BodyDef.position.set(2.5f, 1.5f);
        platform1Body = world.createBody(platform1BodyDef);
        platform1Body.createFixture(fixtureDef);


        BodyDef platform2BodyDef = new BodyDef();
        platform2BodyDef.type = BodyDef.BodyType.StaticBody;
        platform2BodyDef.position.set(5f, 3f);
        platform2Body = world.createBody(platform2BodyDef);
        platform2Body.createFixture(fixtureDef);

        shape.dispose();


        int platformWidthPixels = (int)(platformWidthMeters * PIXELS_TO_METERS);
        int platformHeightPixels = (int)(platformHeightMeters * PIXELS_TO_METERS);
        platformPixmap = new Pixmap(platformWidthPixels, platformHeightPixels, Pixmap.Format.RGBA8888);
        //
        platformPixmap.fill();
        platform1Texture = new Texture(platformPixmap);
        //
        platformPixmap.fill();
        platform2Texture = new Texture(platformPixmap);
        platformPixmap.dispose();
        platform1Sprite = new Sprite(platform1Texture);
        platform1Sprite.setPosition(platform1Body.getPosition().x * PIXELS_TO_METERS - platform1Sprite.getWidth()/2,
            platform1Body.getPosition().y * PIXELS_TO_METERS - platform1Sprite.getHeight()/2);
        platform2Sprite = new Sprite(platform1Texture);
        platform2Sprite.setPosition(platform2Body.getPosition().x * PIXELS_TO_METERS - platform2Sprite.getWidth()/2,
            platform2Body.getPosition().y * PIXELS_TO_METERS - platform2Sprite.getHeight()/2);
    }



    private void addContacts() {
        world.setContactListener(new ContactListener() {
            @Override
            public void beginContact(Contact contact) {

                if ((contact.getFixtureA().getBody() == body &&
                    contact.getFixtureB().getBody() == platform2Body) ||
                    (contact.getFixtureA().getBody() == platform2Body &&
                        contact.getFixtureB().getBody() == body)) {


                    float bodyBaseY = body.getPosition().y - sprite.getHeight()/2/PIXELS_TO_METERS;
                    float platform2TopY = platform2Body.getPosition().y + platformHeightMeters/2;
                    if (bodyBaseY >= platform2TopY) {
                        goalReachedSound.resume();
                        goalReached = true;
                    }
                }
            }

            @Override
            public void endContact(Contact contact) {
                goalReachedSound.pause();
                goalReached = false;
            }

            @Override
            public void preSolve(Contact contact, Manifold oldManifold) {
            }

            @Override
            public void postSolve(Contact contact, ContactImpulse impulse) {

            }
        });
    }


    public void render(float delta) {
        camera.update();

        world.step(1f / 60f, 6, 2);
        // Update sprite position
        sprite.setPosition((body.getPosition().x * PIXELS_TO_METERS) - sprite.getWidth() / 2,
            (body.getPosition().y * PIXELS_TO_METERS) - sprite.getHeight() / 2);

        sprite.setRotation((float) Math.toDegrees(body.getAngle()));

        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.batch.setProjectionMatrix(camera.combined);
        debugMatrix = game.batch.getProjectionMatrix().cpy().scale(PIXELS_TO_METERS, PIXELS_TO_METERS, 0);

        game.batch.begin();
        if (drawSprite) {
            sprite.draw(game.batch);
            platform1Sprite.draw(game.batch);
            platform2Sprite.draw(game.batch);
        }
        game.font.draw(game.batch, "(Hit Escape to return to main menu)", 10, Gdx.graphics.getHeight() - 10);
        if (goalReached) {
            game.font.draw(game.batch, "GOAL REACHED!", camera.position.x-100, camera.position.y);
        }
        game.batch.end();


        updateSprite();



        elapsedTime += delta;
        sprite.updateSprite(elapsedTime);

        debugRenderer.render(world, debugMatrix);
    }


    private void updateSprite() {
        // Get current y velocity
        float vy = body.getLinearVelocity().y;
        // Debug:
        // System.out.println("vy: " + vy);

        // If not currently jumping ...
        float notJumpingThreshold = .01f;
        if (Math.abs(vy) < notJumpingThreshold ) {
            if (right) {
                body.setLinearVelocity(WALKVELOCITY, 0);

                sprite.setState(false, true, false);
            }
            if (left) {
                body.setLinearVelocity(-WALKVELOCITY, 0);
                sprite.setState(true, false, false);
            }
            if (jump) {
                body.applyForceToCenter(0f, JUMPFORCE, true);
                jumpSound.play();
                sprite.setState(false, false, true);
            }
        }
        else
            sprite.setState(false, false, false);


        float notWalkingThreshold = .1f;
        if (Math.abs(body.getLinearVelocity().x) < notWalkingThreshold)
            sprite.setState(false, false, false);
    }

    // InputProcessor interface method overrides:
    @Override
    public boolean keyDown(int keycode) {
        if (keycode == Input.Keys.RIGHT)
            right = true;
        if (keycode == Input.Keys.LEFT)
            left = true;
        // Jump with UP
        if (keycode == Input.Keys.UP)
            jump = true;

        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        if (keycode == Input.Keys.RIGHT)
            right = false;
        if (keycode == Input.Keys.LEFT)
            left = false;

        // Jump with UP
        if (keycode == Input.Keys.UP)
            jump = false;
        // body.applyForceToCenter(0f, 5f, true);

        // Reset everything with SPACE
        if (keycode == Input.Keys.SPACE) {
            body.setLinearVelocity(0f, 0f);
            body.setAngularVelocity(0f);

            sprite.setPosition(Gdx.graphics.getWidth() / 2 - sprite.getWidth() / 2,
                Gdx.graphics.getHeight() / 2);
            body.setTransform((sprite.getX() + sprite.getWidth() / 2) / PIXELS_TO_METERS,
                (sprite.getY() + sprite.getHeight() / 2) / PIXELS_TO_METERS, 0f);
        }

        // Toggle sprite visibility with 1
        if (keycode == Input.Keys.NUM_1)
            drawSprite = !drawSprite;

        // Escape to MainMenuScreen
        if (keycode == Input.Keys.ESCAPE) {
            game.setScreen(mainmenu);
            dispose();
        }

        return false;
    } // end keyUp()

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }


    // Screen interface method overrides:
    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        world.dispose();
        debugRenderer.dispose();
        jumpSound.dispose();
        goalReachedSound.dispose();
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

}

