//Brandon Garsson s1293728
/*



package com.gamefromscratch;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;

public class P2AnimatedSprite extends Sprite {
    private TextureAtlas textureAtlas;

    private Animation walkDownAnimation;
    private Animation walkLeftAnimation;
    private Animation walkRightAnimation;
    private Animation walkUpAnimation;

    private Array<TextureAtlas.AtlasRegion> walkDownFrames;
    private Array<TextureAtlas.AtlasRegion> walkLeftFrames;
    private Array<TextureAtlas.AtlasRegion> walkRightFrames;
    private Array<TextureAtlas.AtlasRegion> walkUpFrames;

    //States
    private boolean walking;
    private boolean walkingDown;
    private boolean walkingUp;
    private boolean walkingLeft;
    private boolean walkingRight;
    private boolean jumping;

    //Sounds
    private Sound walkingSound;

    public P2AnimatedSprite() {
        //
        textureAtlas = new TextureAtlas(Gdx.files.internal("proj2_sprite/p2_anim_sprite.atlas"));
        float frameDuration = 1 / 5f;
        walkDownFrames = textureAtlas.findRegions("walk_down");
        walkDownAnimation = new Animation(frameDuration, walkDownFrames);
        walkUpFrames = textureAtlas.findRegions("walk_up");
        walkUpAnimation = new Animation(frameDuration, walkUpFrames);
        walkLeftFrames = textureAtlas.findRegions("walk_left");
        walkLeftAnimation = new Animation(frameDuration, walkLeftFrames);
        walkRightFrames = textureAtlas.findRegions("walk_right");
        walkRightAnimation = new Animation(frameDuration, walkRightFrames);

        setBounds(0, 0, walkDownFrames.get(0).getRegionWidth(),
            walkDownFrames.get(0).getRegionHeight());
        setRegion(walkDownFrames.get(0));

        walkingSound = Gdx.audio.newSound(Gdx.files.internal("sounds/walk.mp3"));
        walkingSound.loop();
        walkingSound.pause();
    }


    public void setState(boolean down, boolean up, boolean left, boolean right, boolean jump) {
        walkingDown = down;
        walkingUp = up;
        walkingLeft = left;
        walkingRight = right;
        jumping = jump;
        if ((walkingDown || walkingUp || walkingLeft || walkingRight) && !jumping)
            walking = true;
        else
            walking = false;
    }


    public void updateSprite(float elapsedTime) {
        if (walking) {
            walkingSound.resume();

            if (walkingDown)
                setRegion((TextureRegion) walkDownAnimation.getKeyFrame(elapsedTime, true));
            else if (walkingUp)
                setRegion((TextureRegion) walkUpAnimation.getKeyFrame(elapsedTime, true));
            else if (walkingLeft)
                setRegion((TextureRegion) walkLeftAnimation.getKeyFrame(elapsedTime, true));
            else if (walkingRight)
                setRegion((TextureRegion) walkRightAnimation.getKeyFrame(elapsedTime, true));
        } else
            walkingSound.pause();

    }


}
*/
