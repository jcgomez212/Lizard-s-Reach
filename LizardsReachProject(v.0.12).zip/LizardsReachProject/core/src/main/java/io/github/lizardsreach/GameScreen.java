package io.github.lizardsreach;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.Iterator;

public class GameScreen extends ApplicationAdapter {
    private SpriteBatch batch;
    private Texture cityBackground;
    private TextureAtlas lizardAtlas;
    private Animation<TextureRegion> lizardAnimation;
    private TextureRegion currentFrame; // Current frame of animation
    private TextureRegion idleFrame; // AA: Added to hold the idle frame
    private TextureAtlas flyAtlas;
    private Animation<TextureRegion> flyAnimation;
    private float stateTime;
    private float lizardX, lizardY;
    private float jumpVelocity;
    private boolean isJumping;
    private boolean isMoving; // AA: Added to track if the Lizard Man is moving
    private boolean isAttacking; // To track if the Lizard Man is attacking
    private boolean isFlipped;
    private boolean isOnCooldown; // Tracks if the player is on cooldown
    private float cooldownTimer; // Tracks cooldown duration
    private float attackStartX, attackStartY, attackEndX, attackEndY; // Rectangle points
    private Array<Fly> flies; // List of flies on screen
    private int score; // Tracks the player's score
    private BitmapFont font;

    // Camera and viewport settings
    private static final int VIRTUAL_WIDTH = 960;
    private static final int VIRTUAL_HEIGHT = 720;
    private OrthographicCamera camera;
    private Viewport viewport;

    @Override
    public void create() {
        batch = new SpriteBatch();

        // Set up camera and viewport
        camera = new OrthographicCamera();
        viewport = new FitViewport(VIRTUAL_WIDTH, VIRTUAL_HEIGHT, camera);

        // Load background texture
        cityBackground = new Texture("cityBackground.png");

        // Load Lizard Man's atlas and animation
        lizardAtlas = new TextureAtlas(Gdx.files.internal("LizardSprite.txt"));
        Array<TextureRegion> walkingFrames = new Array<>();
        for (int i = 0; i < lizardAtlas.getRegions().size - 1; i++) { // Exclude the last frame
            walkingFrames.add(lizardAtlas.getRegions().get(i));
        }
        lizardAnimation = new Animation<>(0.1f, walkingFrames);
        idleFrame = lizardAtlas.getRegions().first(); // AA: Set the first frame as the idle frame
        lizardX = VIRTUAL_WIDTH / 2f - 75; // Initial Lizard Man X position
        lizardY = 50; // Initial Lizard Man Y position
        stateTime = 0f;
        jumpVelocity = 0f;
        isJumping = false;
        isMoving = false; // AA: Initialize isMoving as false
        isAttacking = false;
        score = 0;

        font = new BitmapFont(); // Use default font
        font.getData().setScale(2); // Scale the font for better visibility
        font.setColor(1, 1, 1, 1); // Set font color to white

        // Load Fly's atlas and animation
        flyAtlas = new TextureAtlas(Gdx.files.internal("FlySprite.txt"));
        flyAnimation = new Animation<>(0.1f, flyAtlas.getRegions());
        flies = new Array<>();
    }

    @Override
    public void render() {
        // Update camera and apply viewport
        camera.update();
        batch.setProjectionMatrix(camera.combined);

        // Clear the screen
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);

        // Update state time
        stateTime += Gdx.graphics.getDeltaTime();

        // Handle input for Lizard Man movement and jumping
        handleInput();

        // Cooldown timer
        if (isOnCooldown) {
            cooldownTimer -= Gdx.graphics.getDeltaTime();
            if (cooldownTimer <= 0) {
                isOnCooldown = false;
                isAttacking = false; // End attack phase
            }
        }

        // Update rectangle position if attacking
        if (isAttacking) {
            attackStartX = lizardX + currentFrame.getRegionWidth() * 1.5f; // Center of the sprite
            attackStartY = lizardY + currentFrame.getRegionHeight() * 3;

            // Update direction vector for the rectangle endpoint
            float dx = attackEndX - attackStartX;
            float dy = attackEndY - attackStartY;
            float distance = (float) Math.sqrt(dx * dx + dy * dy);

            if (distance > 250) {
                float scale = 250 / distance;
                attackEndX = attackStartX + dx * scale;
                attackEndY = attackStartY + dy * scale;
            }
        }

        // Update current frame based on state
        if (isAttacking) {
            // Use the last frame for attack animation
            currentFrame = lizardAtlas.getRegions().get(lizardAtlas.getRegions().size - 1);
        } else if (isMoving || isJumping) { // AA: Play animation only if moving or jumping
            currentFrame = lizardAnimation.getKeyFrame(stateTime, true);
        } else {
            currentFrame = idleFrame; // AA: Use idle frame if not moving
        }

        // Update flies
        updateFlies();

        // Draw everything
        batch.begin();
        batch.disableBlending();
        drawBackground();
        batch.enableBlending();
        if (isAttacking) drawAttackRectangle(); // Draw rectangle during attack
        drawLizardMan();
        drawFlies();
        //drawFlyRectangles();
        font.draw(batch, "Score: " + score, 10, VIRTUAL_HEIGHT - 10); // Display score at the top-left corner
        batch.end();

        // Update jumping logic
        updateJump();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height); // Update viewport on resize
        camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0);
    }

    private void drawBackground() {
        batch.draw(cityBackground, 0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    }

    private void drawLizardMan() {
        // Flip the sprite if needed
        if (isFlipped && !currentFrame.isFlipX()) {
            currentFrame.flip(true, false); // Flip horizontally
        } else if (!isFlipped && currentFrame.isFlipX()) {
            currentFrame.flip(true, false); // Unflip if moving right
        }
        batch.draw(currentFrame, lizardX, lizardY, currentFrame.getRegionWidth() * 3, currentFrame.getRegionHeight() * 3); // Scaled by 3x
    }

    private void drawAttackRectangle() {
        batch.end(); // End the batch to use shapes
        ShapeRenderer shapeRenderer = new ShapeRenderer();
        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(1, 0, 0, 1); // Red color
        shapeRenderer.rectLine(attackStartX, attackStartY, attackEndX, attackEndY, 5); // Thickness of 5
        shapeRenderer.end();
        batch.begin(); // Resume the batch
    }

    private void drawFlies() {
        Iterator<Fly> iterator = flies.iterator();
        while (iterator.hasNext()) {
            Fly fly = iterator.next();
            TextureRegion currentFrame = flyAnimation.getKeyFrame(stateTime, true);

            // Flip the sprite if necessary
            if (fly.flipped && !currentFrame.isFlipX()) {
                currentFrame.flip(true, false); // Flip horizontally
            } else if (!fly.flipped && currentFrame.isFlipX()) {
                currentFrame.flip(true, false); // Unflip if moving right
            }

            // Check for collision with the attack rectangle
            if (isAttacking && fly.boundingBox.overlaps(new Rectangle(attackStartX, attackStartY,
                attackEndX - attackStartX, attackEndY - attackStartY))) {
                score += 100; // Add 100 points for each hit
                iterator.remove(); // Remove the fly
                continue; // Skip drawing the removed fly
            }

            // Draw the fly
            batch.draw(currentFrame, fly.x - fly.size / 2, fly.y, fly.size, fly.size);
            fly.update(Gdx.graphics.getDeltaTime()); // Update fly position and rectangle

            // Remove flies that exit the screen
            if (fly.x < -fly.size || fly.x > VIRTUAL_WIDTH + fly.size) {
                iterator.remove();
            }
        }
    }

    private void handleInput() {
        if (isOnCooldown) return;
        isMoving = false; // AA: Reset isMoving before checking input

        if (Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.LEFT) ||
            (Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.A))) {
            lizardX -= 200 * Gdx.graphics.getDeltaTime();
            isMoving = true; // AA: Set isMoving to true when moving left
            isFlipped = true;
        }
        if (Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.RIGHT) ||
            (Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.D))) {
            lizardX += 200 * Gdx.graphics.getDeltaTime();
            isMoving = true; // AA: Set isMoving to true when moving right
            isFlipped = false;
        }
        if ((Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.SPACE) ||
            Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.UP)  ||
            (Gdx.input.isKeyPressed(com.badlogic.gdx.Input.Keys.W))) && !isJumping) {
            isJumping = true;
            jumpVelocity = 800f;
        }
        // Attack on mouse click
        if (Gdx.input.isButtonJustPressed(com.badlogic.gdx.Input.Buttons.LEFT)) {
            isAttacking = true;
            isOnCooldown = true;
            cooldownTimer = 0.8f;

            // Calculate attack rectangle points
            attackStartX = lizardX + currentFrame.getRegionWidth() * 1.5f; // Center of the sprite
            attackStartY = lizardY + currentFrame.getRegionHeight() * 3;   // Top of the sprite


            // Get mouse click position in world coordinates
            float clickX = camera.unproject(new com.badlogic.gdx.math.Vector3(Gdx.input.getX(), Gdx.input.getY(), 0)).x;
            float clickY = camera.unproject(new com.badlogic.gdx.math.Vector3(Gdx.input.getX(), Gdx.input.getY(), 0)).y;

            // Calculate direction vector and distance
            float dx = clickX - attackStartX;
            float dy = clickY - attackStartY;
            float distance = (float) Math.sqrt(dx * dx + dy * dy);

            if (distance > 250) {
                // Limit the rectangle length to 250 pixels
                float scale = 250 / distance;
                attackEndX = attackStartX + dx * scale;
                attackEndY = attackStartY + dy * scale;
            } else {
                // Use the exact click position if within range
                attackEndX = clickX;
                attackEndY = clickY;
            }
        } else {
            isAttacking = false;
        }
    }

    private void updateJump() {
        if (isJumping) {
            lizardY += jumpVelocity * Gdx.graphics.getDeltaTime();
            jumpVelocity -= 1200 * Gdx.graphics.getDeltaTime(); // Gravity effect

            if (lizardY <= 50) {
                lizardY = 50;
                isJumping = false;
            }
        }


    }

    private void updateFlies() {
        if (MathUtils.random(0, 100) < 2) { // Random chance to spawn a fly
            float flySize = MathUtils.random(30, 70);
            float flySpeed = MathUtils.random(150, 300);
            float flyY = MathUtils.random(100, VIRTUAL_HEIGHT - flySize - 50);

            // Randomly decide whether the fly spawns on the left or right
            if (MathUtils.randomBoolean()) {
                // Spawn on the left and move right
                flies.add(new Fly(0, flyY, flySize, flySpeed, false));
            } else {
                // Spawn on the right and move left
                flies.add(new Fly(VIRTUAL_WIDTH, flyY, flySize, -flySpeed, true));
            }
        }
    }

    @Override
    public void dispose() {
        batch.dispose();
        cityBackground.dispose();
        lizardAtlas.dispose();
        flyAtlas.dispose();
        font.dispose();
    }

    // Inner class for managing fly properties
    private static class Fly {
        float x, y, size, speed;
        boolean flipped; // Whether the sprite should be flipped
        Rectangle boundingBox;

        Fly(float x, float y, float size, float speed, boolean flipped) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.speed = speed;
            this.flipped = flipped;

            // Initialize the bounding box
            this.boundingBox = new Rectangle(x - size / 2, y, size, size); // Match the fly's size and render offset
        }

        void update(float deltaTime) {
            x += speed * deltaTime; // Move the fly
            boundingBox.setPosition(x - size / 2, y); // Update the bounding box to align with the rendered position
        }
    }

    private void drawFlyRectangles() {
        ShapeRenderer shapeRenderer = new ShapeRenderer();
        shapeRenderer.setProjectionMatrix(camera.combined);

        // Start the ShapeRenderer after the batch
        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(0, 1, 0, 1); // Green for debugging
        for (Fly fly : flies) {
            shapeRenderer.rect(fly.boundingBox.x, fly.boundingBox.y, fly.boundingBox.width, fly.boundingBox.height);
        }
        shapeRenderer.end();
    }

}
